from src.ivi_simulator.cli import main

if __name__ == "__main__":
    raise SystemExit(main())
